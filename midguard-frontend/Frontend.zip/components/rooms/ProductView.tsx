"use client";

type Product = {
  name: string;
  sellerId: string;
  price: number;
  description: string;
  usedDuration?: string;
  warranty?: string;
  invoiceAvailable?: boolean;
  originalBox?: boolean;
};

type Props = {
  product: Product;
};

export default function ProductView({ product }: Props) {
  return (
    <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-6 shadow-lg space-y-6">

      {/* TOP GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

        {/* LEFT SIDE */}
        <div className="space-y-3">
          <h1 className="text-xl font-semibold leading-snug">
            {product.name}
          </h1>

          <div className="text-sm text-gray-400">
            Seller: <span className="text-white">{product.sellerId}</span>
          </div>

          <div className="text-3xl font-bold text-orange-400">
            ₹{product.price.toLocaleString()}
          </div>
        </div>

        {/* RIGHT SIDE (ATTRIBUTES) */}
        <div className="grid grid-cols-2 gap-3 text-sm">

          {product.usedDuration && (
            <div className="bg-white/10 p-3 rounded-lg">
              <p className="text-gray-400 text-xs">Used Duration</p>
              <p className="text-white">{product.usedDuration}</p>
            </div>
          )}

          {product.warranty && (
            <div className="bg-white/10 p-3 rounded-lg">
              <p className="text-gray-400 text-xs">Warranty</p>
              <p className="text-white">{product.warranty}</p>
            </div>
          )}

          {product.originalBox !== undefined && (
            <div className="bg-white/10 p-3 rounded-lg">
              <p className="text-gray-400 text-xs">Original Box</p>
              <p className="text-white">
                {product.originalBox ? "Available" : "No"}
              </p>
            </div>
          )}

          {product.invoiceAvailable !== undefined && (
            <div className="bg-white/10 p-3 rounded-lg">
              <p className="text-gray-400 text-xs">Invoice</p>
              <p className="text-white">
                {product.invoiceAvailable ? "Available" : "No"}
              </p>
            </div>
          )}

        </div>
      </div>

      {/* DESCRIPTION */}
      <div className="bg-white/10 p-4 rounded-xl">
        <h2 className="text-sm font-semibold mb-2">Description</h2>
        <p className="text-gray-300 text-sm leading-relaxed">
          {product.description}
        </p>
      </div>

    </div>
  );
}