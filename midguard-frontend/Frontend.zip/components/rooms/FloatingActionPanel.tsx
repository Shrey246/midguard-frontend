//BidPanel.tsx
//Purpose: nothing fancy but a glass UI with Room type,wishlist,buynow options.
/*Props: A rounded rectangluar glass card upon it towards left would be room type and towards right options to buy now or wishlist*/
//Where it's used: all rooms excpet auction room 

"use client";

type Action = {
  label: string;
  onClick: () => void;
  variant?: "primary" | "secondary";
};

type Props = {
  roomType: "public" | "private" | "digital";
  actions: Action[];
};

export default function FloatingActionPanel({
  roomType,
  actions,
}: Props) {
  return (
    <div className="sticky bottom-4 z-50">

      <div className="flex items-center justify-between gap-4 
        bg-white/5 backdrop-blur-xl p-4 rounded-2xl shadow-xl">

        {/* LEFT: ROOM TYPE */}
        <div className="text-sm text-gray-400">
          Room:{" "}
          <span className="text-white capitalize font-medium">
            {roomType}
          </span>
        </div>

        {/* RIGHT: ACTIONS */}
        <div className="flex gap-3">
          {actions.map((action, i) => (
            <button
              key={i}
              onClick={action.onClick}
              className={`px-5 py-2 rounded-xl font-medium transition ${
                action.variant === "primary"
                  ? "bg-orange-500 hover:bg-orange-600 text-white"
                  : "bg-white/10 hover:bg-white/20 text-white"
              }`}
            >
              {action.label}
            </button>
          ))}
        </div>

      </div>
    </div>
  );
}