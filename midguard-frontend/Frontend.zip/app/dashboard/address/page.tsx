"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";

export default function AddressPage() {
  const [addresses, setAddresses] = useState<any[]>([]);

  const loadAddresses = async () => {
    try {
      const res = await api.getAddresses();
      setAddresses(res.addresses || []);;
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    loadAddresses();
  }, []);

  const handleDelete = async (id: string) => {
    await api.deleteAddress(id);
    loadAddresses();
  };

  const handleDefault = async (id: string) => {
    await api.setDefaultAddress(id);
    loadAddresses();
  };

  return (
    <div className="p-6 text-white">

      <h1 className="text-2xl font-bold mb-6">Saved Addresses</h1>

      <div className="grid grid-cols-3 gap-6">

        {/* ADD NEW CARD */}
        <div className="border border-dashed border-gray-500 rounded-xl flex items-center justify-center h-[180px] cursor-pointer hover:border-cyan-400"
          onClick={() => window.location.href = "/dashboard/Createaddress"}>
          <span className="text-gray-400">+ Add Address</span>
        </div>

        {/* ADDRESS LIST */}
        {addresses.map((addr) => (
          <div
            key={addr.address_uid}
            className={`p-4 rounded-xl border ${
              addr.is_default
                ? "border-cyan-400 bg-white/5"
                : "border-white/10"
            }`}
          >
            <div className="flex justify-between">
              <h2 className="font-semibold">{addr.full_name}</h2>
              {addr.is_default && (
                <span className="text-xs text-cyan-400">Default</span>
              )}
            </div>

            <p className="text-sm mt-2">
              {addr.address_line1}, {addr.address_line2}
            </p>

            <p className="text-sm">
              {addr.city}, {addr.state} - {addr.postal_code}
            </p>

            <p className="text-sm mt-1">{addr.country}</p>
            <p className="text-xs text-gray-400 mt-1">
              Phone: {addr.phone_number}
            </p>

            {/* ACTIONS */}
            <div className="flex justify-between mt-4 text-sm">
              <button
                onClick={() => handleDefault(addr.address_uid)}
                className="text-cyan-400"
              >
                Set default
              </button>

              <button
                onClick={() => handleDelete(addr.address_uid)}
                className="text-red-400"
              >
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}