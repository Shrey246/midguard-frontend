"use client";

import { useState } from "react";
import { api } from "@/lib/api";
import { useRouter } from "next/navigation";

export default function CreateAddress() {
  const router = useRouter();

  const [form, setForm] = useState({
    label: "home",
    full_name: "",
    phone_number: "",
    address_line1: "",
    address_line2: "",
    city: "",
    state: "",
    postal_code: "",
    country: "India",
    is_default: false,
  });

  const handleChange = (e: any) => {
    const { name, value, type, checked } = e.target;
    setForm({
      ...form,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  const handleSubmit = async () => {
    try {
      await api.createAddress(form);
      router.push("/dashboard/address");
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="p-6 text-white max-w-xl mx-auto">

      <h1 className="text-2xl font-bold mb-6">Add New Address</h1>

      <div className="space-y-4">

        <select
          name="label"
          onChange={handleChange}
          className="w-full p-2 rounded bg-white/5"
        >
          <option value="home">Home</option>
          <option value="work">Work</option>
          <option value="other">Other</option>
        </select>

        <input name="full_name" placeholder="Full Name" onChange={handleChange} className="w-full p-2 rounded bg-white/5" />

        <input name="phone_number" placeholder="Phone Number" onChange={handleChange} className="w-full p-2 rounded bg-white/5" />

        <input name="postal_code" placeholder="Pincode" onChange={handleChange} className="w-full p-2 rounded bg-white/5" />

        <input name="address_line1" placeholder="Flat, Building..." onChange={handleChange} className="w-full p-2 rounded bg-white/5" />

        <input name="address_line2" placeholder="Area, Street..." onChange={handleChange} className="w-full p-2 rounded bg-white/5" />

        <input name="city" placeholder="City" onChange={handleChange} className="w-full p-2 rounded bg-white/5" />

        <input name="state" placeholder="State" onChange={handleChange} className="w-full p-2 rounded bg-white/5" />

        <label className="flex gap-2 items-center">
          <input type="checkbox" name="is_default" onChange={handleChange} />
          Make default
        </label>

        <button
          onClick={handleSubmit}
          className="w-full py-2 rounded bg-cyan-400 text-black font-semibold"
        >
          Add Address
        </button>
      </div>
    </div>
  );
}